# EngramControl v4.1

Block engrams and unlock them via creature kills with multi-kill requirements.

## Features

- Block engrams by name pattern (partial match supported)
- Unlock engrams by killing specific creatures
- **Multi-kill requirements**: Require killing multiple different creatures to unlock engrams
- Player progress persists through mindwipes
- License validation for full features

## Installation

1. Copy `EngramControl.dll` to `ArkApi/Plugins/EngramControl/`
2. Copy `config.json` to `ArkApi/Plugins/EngramControl/`
3. Edit config.json with your settings
4. Restart server or load plugin

## Configuration

### BlockedEngrams
Array of engram name patterns to block. Supports partial matching.

```json
"BlockedEngrams": [
  "EngramEntry_TekReplicator",
  "Kibble_Toxic"
]
```

### KillUnlocks
Define unlock requirements. Each unlock requires killing ALL creatures in the `required_kills` array.

```json
"KillUnlocks": {
  "TekReplicator": {
    "engrams": ["EngramEntry_TekReplicator"],
    "required_kills": [
      "BossArena_Broodmother",
      "BossArena_Megapithecus",
      "BossArena_Dragon"
    ]
  }
}
```

Players must kill one of each creature type to unlock the engrams.

## Console Commands

- `EngramControl.Reload` - Reload config (admin only)
- `EngramControl.Find <pattern>` - Search for engram names (admin only)
- `EngramControl.Progress` - Show your unlock progress (all players)

## License

Free mode: 5 blocked engrams, no kill unlocks
Licensed: Unlimited engrams, kill unlocks, persistent player data

Purchase license at https://ko-fi.com/rokiarknet
