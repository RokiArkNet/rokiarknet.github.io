# TekUnlock v1.1

Directly teach engrams to players when specific creatures are killed. All players within radius automatically learn the engrams.

## Features

- **Kill-based grants**: Kill creatures to auto-learn engrams (no manual learning required)
- **Variable unlock count**: Randomly grant N engrams from a pool (v1.1)
- **Smart filtering**: Only grants engrams the player doesn't already have
- **Radius detection**: All players near the kill get the reward
- **Persistent unlocks**: Unlocked engrams survive mindwipes
- **Chat notifications**: Players see what they unlocked

## Installation

1. Copy the `TekUnlock` folder to your server's `ArkApi/Plugins/` directory
2. Edit `config.json` with your creature -> engram mappings
3. Restart the server

## Configuration

### Settings

```json
"Settings": {
  "ChatPrefix": "TekUnlock",
  "UnlockRadius": 50000.0,
  "MessageOnUnlock": true
}
```

- `ChatPrefix`: Prefix for chat messages
- `UnlockRadius`: Distance from kill to receive rewards (50000 = ~500m)
- `MessageOnUnlock`: Show chat notification when engrams are granted

### Kill Unlocks

**Simple format** - grant all engrams:
```json
"KillUnlocks": {
  "Broodmother_Character_BP": [
    "Blueprint'/Game/.../PrimalItemStructure_TekReplicator'",
    "Blueprint'/Game/.../PrimalItemStructure_TekGenerator'"
  ]
}
```

**Advanced format** - grant random N engrams:
```json
"KillUnlocks": {
  "Megapithecus_Character_BP": {
    "engrams": [
      "Blueprint'/Game/.../PrimalItemArmor_TekHelmet'",
      "Blueprint'/Game/.../PrimalItemArmor_TekShirt'",
      "Blueprint'/Game/.../PrimalItemArmor_TekPants'",
      "Blueprint'/Game/.../PrimalItemArmor_TekBoots'",
      "Blueprint'/Game/.../PrimalItemArmor_TekGloves'"
    ],
    "minUnlock": 1,
    "maxUnlock": 2
  }
}
```

With `minUnlock: 1` and `maxUnlock: 2`, killing Megapithecus grants 1-2 random Tek armor pieces that the player doesn't already have.

### Options

| Field | Description |
|-------|-------------|
| `engrams` | Array of blueprint paths to grant |
| `unlockCount` | Exact number to grant (alternative to min/max) |
| `minUnlock` | Minimum engrams to grant |
| `maxUnlock` | Maximum engrams to grant (random between min-max) |

## Console Commands

| Command | Description |
|---------|-------------|
| `TekUnlock.Reload` | Reload configuration (admin only) |
| `TekUnlock.List` | Show loaded kill rules (admin only) |

## Notes

- Only wild creature kills trigger unlocks (tamed don't count)
- Players must be within radius when the creature dies
- Already-known engrams are skipped (no duplicates)

## Version History

- **v1.1** - Variable unlock count (minUnlock/maxUnlock), smart filtering
- **v1.0** - Initial release

## Author

Rokitur - RokiArkNet
