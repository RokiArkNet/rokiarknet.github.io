# EngramControl Plugin for ARK: Survival Ascended

Control engram progression with a per-player unlock system. Block engrams globally, unlock via creature kills or RCON commands. Perfect for custom progression systems.

## Features

- **Block Engrams Globally** - Configure which engrams are blocked for all players
- **Kill-Based Unlocks** - Players unlock engrams by killing specific creatures
- **Per-Player Persistence** - Unlocks survive mindwipes and character transfers
- **RCON Integration** - All commands available via RCON for admin/shop integration
- **Pattern Matching** - Block engrams by partial name matching

## Installation

1. Copy the `EngramControl` folder to:
   ```
   ShooterGame/Binaries/Win64/ArkApi/Plugins/
   ```

2. Edit `config.json` and add your license key:
   ```json
   "LicenseKey": "XXXX-XXXX-XXXX-XXXX"
   ```

3. Restart the server

## Configuration

### config.json

```json
{
  "General": {
    "Debug": false,
    "LogBlocks": true,
    "LogUnlocks": true
  },
  "BlockedEngrams": [
    "EngramEntry_TekReplicator",
    "EngramEntry_TekGenerator"
  ],
  "KillUnlocks": {
    "BossArena_Broodmother": [
      "EngramEntry_TekReplicator",
      "EngramEntry_TekBoots"
    ]
  },
  "LicenseKey": "XXXX-XXXX-XXXX-XXXX"
}
```

### BlockedEngrams
List of engram class names to block globally. Players cannot learn these until unlocked.

### KillUnlocks
Map of creature names to engrams they unlock when killed. Supports:
- Boss arenas: `BossArena_Broodmother`, `BossArena_Megapithecus`, `BossArena_Dragon`
- Alpha creatures: `Alpha_Rex`, `Alpha_Megalodon`, `Alpha_Carno`
- Any modded creature class name

## RCON Commands

| Command | Description |
|---------|-------------|
| `EngramControl.Reload` | Reload config without restart |
| `EngramControl.Find <pattern>` | Search for engram names matching pattern |

## How It Works

1. Engrams in `BlockedEngrams` are hidden from all players
2. When a player kills a creature listed in `KillUnlocks`, they gain access to the specified engrams
3. Unlocks are stored per-player and persist through mindwipes
4. Players can then learn the unlocked engrams normally

## License

This plugin requires an annual license. Purchase at:
https://ko-fi.com/rokiarknet

**Free Mode**: Without a license, the plugin works with up to 5 blocked engrams (no kill unlocks).

## Requirements

- ARK: Survival Ascended Dedicated Server
- ASA Server API (AsaApi) v1.19 or higher

## Support

- Discord: https://discord.gg/rokiarknet
- GitHub: https://github.com/RokiArkNet

## Author

RokiArkNet
